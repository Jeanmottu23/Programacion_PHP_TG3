<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Sistema Gimnasio</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">

        <a class="navbar-brand" href="{{ route('dashboard') }}">
            Gimnasio
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="menu">

            <ul class="navbar-nav me-auto">

                <li class="nav-item">
                    <a class="nav-link" href="/socios">Socios</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/membresias">Membresías</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/instructores">Instructores</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/clases">Clases</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/inscripciones">Inscripciones</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/asistencias">Asistencias</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/pagos">Pagos</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/auditoria">Auditoría</a>
                </li>

            </ul>

            <!-- USUARIO -->
            <div class="d-flex align-items-center text-white gap-3">

                {{ Auth::user()->name }}

                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button class="btn btn-danger btn-sm">
                        Salir
                    </button>
                </form>

            </div>

        </div>

    </div>
</nav>

<!-- CONTENIDO -->
<div class="container mt-4">

    @yield('content')

</div>

</body>
</html>